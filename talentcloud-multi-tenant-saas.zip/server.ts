import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { TenantConnectionRouter, TenantConnectionContext } from './server/tenant/TenantConnectionRouter.js';
import { evaluateCandidateWithAI } from './server/gemini.js';

dotenv.config();

// Augment Express Request interface with tenantContext
declare global {
  namespace Express {
    interface Request {
      tenantContext?: TenantConnectionContext;
    }
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  const router = TenantConnectionRouter.getInstance();

  app.use(express.json());

  // Healthcheck endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'TalentCloud Multi-Tenant SaaS Core',
      timestamp: new Date().toISOString()
    });
  });

  // ==========================================
  // SUPERADMIN / CONTA MÃE ENDPOINTS
  // ==========================================

  // List all tenants from the Master Catalog
  app.get('/api/master/tenants', (req, res) => {
    try {
      const tenants = router.getAllTenants();
      res.json({ success: true, tenants });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Provision a new organization with isolated database
  app.post('/api/master/tenants/provision', (req, res) => {
    try {
      const { name, tradingName, slug, document, contactEmail, plan, region, engineType, adminUserName, adminUserEmail } = req.body;
      if (!name || !slug || !contactEmail) {
        return res.status(400).json({ success: false, error: 'Campos obrigatórios: name, slug, contactEmail' });
      }

      const result = router.provisionNewOrganization({
        name,
        tradingName: tradingName || name,
        slug,
        document: document || '00.000.000/0001-00',
        contactEmail,
        plan: plan || 'Scale',
        region: region || 'southamerica-east1',
        engineType: engineType || 'PostgreSQL-Isolated',
        adminUserName: adminUserName || 'Administrador Org',
        adminUserEmail: adminUserEmail || contactEmail
      });

      res.status(201).json({ success: true, ...result });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Update tenant status (Active, Suspended, Maintenance)
  app.patch('/api/master/tenants/:id/status', (req, res) => {
    try {
      const { status } = req.body;
      const updated = router.updateOrganizationStatus(req.params.id, status);
      res.json({ success: true, tenant: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // SuperAdmin Global Telemetry & Cross-Tenant Analytics
  app.get('/api/master/telemetry', (req, res) => {
    try {
      const telemetry = router.getGlobalTelemetry();
      res.json({ success: true, telemetry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Master Audit Logs (Isolation, Provisioning, Routing trace)
  app.get('/api/master/audit-logs', (req, res) => {
    try {
      const logs = router.getMasterAuditLogs();
      res.json({ success: true, logs });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // =========================================================================
  // DYNAMIC TENANT CONNECTION ROUTING MIDDLEWARE
  // Resolves tenant dynamically and mounts isolated database connection
  // =========================================================================
  const tenantRoutingMiddleware = (req: Request, res: Response, next: NextFunction) => {
    try {
      const context = router.routeConnection(req);
      req.tenantContext = context;

      // Expose routing metadata in response headers for transparency & debugging
      res.setHeader('X-Resolved-Tenant-Id', context.tenant.id);
      res.setHeader('X-Isolated-Database', context.tenant.dbConfig.dbName);
      res.setHeader('X-Routing-Strategy', context.resolution.strategy);
      res.setHeader('X-Routing-Latency-Ms', context.resolution.latencyMs.toString());

      next();
    } catch (err: any) {
      res.status(403).json({
        success: false,
        error: err.message,
        tip: 'Verifique se a organização está ativa e se o cabeçalho X-Tenant-Slug ou X-Tenant-Id é válido.'
      });
    }
  };

  // Mount router middleware on all /api/v1 routes
  app.use('/api/v1', tenantRoutingMiddleware);

  // ---------------------------------------------------------
  // MÓDULO 1: Contexto e Conexão da Organização Ativa
  // ---------------------------------------------------------
  app.get('/api/v1/context', (req: Request, res: Response) => {
    const { tenant, telemetry, resolution } = req.tenantContext!;
    res.json({
      success: true,
      tenant,
      telemetry,
      routingResolution: resolution
    });
  });

  // ---------------------------------------------------------
  // MÓDULO 2: Usuários e Permissões (RBAC)
  // ---------------------------------------------------------
  app.get('/api/v1/users', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, users: db.users });
  });

  app.post('/api/v1/users', (req: Request, res: Response) => {
    const { db, tenant } = req.tenantContext!;
    const { name, email, role, jobTitle, departmentId } = req.body;
    const newUser = {
      id: `usr-${tenant.slug}-${Date.now().toString().slice(-4)}`,
      tenantId: tenant.id,
      name,
      email,
      role: role || 'RECRUITER',
      jobTitle: jobTitle || 'Analista de RH',
      departmentId,
      active: true,
      lastLoginAt: new Date().toISOString(),
      permissions: ['JOBS_VIEW', 'CANDIDATES_VIEW']
    };
    db.users.push(newUser);
    res.status(201).json({ success: true, user: newUser });
  });

  // ---------------------------------------------------------
  // MÓDULO 3: DNA Organizacional
  // ---------------------------------------------------------
  app.get('/api/v1/dna', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, dna: db.dna });
  });

  app.put('/api/v1/dna', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { mission, vision, archetype, cultureSummary, coreValues, pillars, culturalFitThreshold } = req.body;
    db.dna = {
      ...db.dna,
      mission: mission ?? db.dna.mission,
      vision: vision ?? db.dna.vision,
      archetype: archetype ?? db.dna.archetype,
      cultureSummary: cultureSummary ?? db.dna.cultureSummary,
      coreValues: coreValues ?? db.dna.coreValues,
      pillars: pillars ?? db.dna.pillars,
      culturalFitThreshold: culturalFitThreshold ?? db.dna.culturalFitThreshold,
      updatedAt: new Date().toISOString()
    };
    res.json({ success: true, dna: db.dna });
  });

  // ---------------------------------------------------------
  // MÓDULO 4: Estrutura Organizacional
  // ---------------------------------------------------------
  app.get('/api/v1/departments', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, departments: db.departments });
  });

  app.post('/api/v1/departments', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { name, code, costCenter, headcountTarget, managerId } = req.body;
    const newDept = {
      id: `dep-${Date.now().toString().slice(-4)}`,
      name,
      code: code || name.slice(0, 4).toUpperCase(),
      costCenter: costCenter || 'CC-1000',
      headcountTarget: Number(headcountTarget) || 10,
      currentHeadcount: 1,
      managerId: managerId || db.users[0]?.id || 'usr-default'
    };
    db.departments.push(newDept);
    res.status(201).json({ success: true, department: newDept });
  });

  // ---------------------------------------------------------
  // MÓDULO 5: Cargos
  // ---------------------------------------------------------
  app.get('/api/v1/positions', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, positions: db.positions });
  });

  app.post('/api/v1/positions', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { title, departmentId, level, description, technicalRequirements, behavioralCompetencies, minSalary, maxSalary, careerTrack } = req.body;
    const newPosition = {
      id: `pos-${Date.now().toString().slice(-4)}`,
      title,
      departmentId,
      level: level || 'Pleno',
      description,
      technicalRequirements: Array.isArray(technicalRequirements) ? technicalRequirements : (technicalRequirements || '').split(',').map((s: string) => s.trim()).filter(Boolean),
      behavioralCompetencies: Array.isArray(behavioralCompetencies) ? behavioralCompetencies : (behavioralCompetencies || '').split(',').map((s: string) => s.trim()).filter(Boolean),
      minSalary: Number(minSalary) || 8000,
      maxSalary: Number(maxSalary) || 12000,
      currency: 'BRL',
      careerTrack: careerTrack || 'Y_TECNICO',
      status: 'active' as const
    };
    db.positions.push(newPosition);
    res.status(201).json({ success: true, position: newPosition });
  });

  // ---------------------------------------------------------
  // MÓDULO 6: Vagas
  // ---------------------------------------------------------
  app.get('/api/v1/openings', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, openings: db.openings });
  });

  app.post('/api/v1/openings', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { title, positionId, departmentId, workModel, location, slaDays, openingsCount, salaryOfferedMin, salaryOfferedMax } = req.body;
    const newOpening = {
      id: `job-${Date.now().toString().slice(-4)}`,
      title,
      positionId: positionId || db.positions[0]?.id || 'pos-1',
      departmentId: departmentId || db.departments[0]?.id || 'dep-1',
      hiringManagerId: db.users.find(u => u.role === 'HIRING_MANAGER')?.id || db.users[0]?.id || 'usr-1',
      recruiterId: db.users.find(u => u.role === 'RECRUITER')?.id || db.users[0]?.id || 'usr-1',
      status: 'open' as const,
      openingsCount: Number(openingsCount) || 1,
      filledCount: 0,
      workModel: workModel || 'Híbrido',
      location: location || 'Remoto / Brasil',
      slaDays: Number(slaDays) || 30,
      openedAt: new Date().toISOString(),
      targetFillDate: new Date(Date.now() + 30 * 86400000).toISOString(),
      salaryOfferedMin: Number(salaryOfferedMin) || undefined,
      salaryOfferedMax: Number(salaryOfferedMax) || undefined,
      stages: [
        { id: 'stg-1', name: 'Triagem Inicial', type: 'screening' as const, order: 1, description: 'Análise de currículo' },
        { id: 'stg-2', name: 'Fit Cultural com IA', type: 'cultural_fit' as const, order: 2, description: 'Aderência ao DNA e explicabilidade' },
        { id: 'stg-3', name: 'Entrevista de Competências', type: 'technical_assessment' as const, order: 3, description: 'Validação técnica ou prática' },
        { id: 'stg-4', name: 'Alinhamento Final', type: 'manager_interview' as const, order: 4, description: 'Conversa com Gestor' },
        { id: 'stg-5', name: 'Proposta & Oferta', type: 'proposal' as const, order: 5, description: 'Envio formal' }
      ]
    };
    db.openings.push(newOpening);
    res.status(201).json({ success: true, opening: newOpening });
  });

  // ---------------------------------------------------------
  // MÓDULO 7: Candidatos
  // ---------------------------------------------------------
  app.get('/api/v1/candidates', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, candidates: db.candidates });
  });

  app.post('/api/v1/candidates', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { name, email, phone, location, currentRole, yearsOfExperience, education, resumeSummary, skills, languages, tags } = req.body;
    const newCandidate = {
      id: `cand-${Date.now().toString().slice(-4)}`,
      name,
      email,
      phone: phone || '+55 11 99999-0000',
      location: location || 'Brasil',
      currentRole: currentRole || 'Profissional',
      yearsOfExperience: Number(yearsOfExperience) || 3,
      education: education || 'Ensino Superior Completo',
      resumeSummary: resumeSummary || 'Perfil cadastrado na plataforma.',
      skills: Array.isArray(skills) ? skills : (skills || '').split(',').map((s: string) => s.trim()).filter(Boolean),
      languages: Array.isArray(languages) ? languages : ['Português (Nativo)'],
      registeredAt: new Date().toISOString(),
      tags: Array.isArray(tags) ? tags : ['Novo Candidato']
    };
    db.candidates.push(newCandidate);
    res.status(201).json({ success: true, candidate: newCandidate });
  });

  // ---------------------------------------------------------
  // MÓDULO 8: Processo Seletivo (Inscrições / Kanban Pipeline)
  // ---------------------------------------------------------
  app.get('/api/v1/applications', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, applications: db.applications });
  });

  app.post('/api/v1/applications', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { candidateId, jobOpeningId } = req.body;
    const job = db.openings.find(j => j.id === jobOpeningId);
    const initialStageId = job?.stages[0]?.id || 'stg-1';

    const newApp = {
      id: `app-${Date.now().toString().slice(-4)}`,
      jobOpeningId,
      candidateId,
      currentStageId: initialStageId,
      status: 'in_review' as const,
      appliedAt: new Date().toISOString(),
      notes: ['Inscrito no processo seletivo.']
    };
    db.applications.push(newApp);
    res.status(201).json({ success: true, application: newApp });
  });

  app.patch('/api/v1/applications/:id/stage', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { stageId, note, status } = req.body;
    const appItem = db.applications.find(a => a.id === req.params.id);
    if (!appItem) return res.status(404).json({ success: false, error: 'Inscrição não encontrada' });

    if (stageId) appItem.currentStageId = stageId;
    if (status) appItem.status = status;
    if (note) appItem.notes.push(`[${new Date().toLocaleDateString('pt-BR')}] ${note}`);

    res.json({ success: true, application: appItem });
  });

  // ---------------------------------------------------------
  // MÓDULO 9: Avaliação Assistida por IA
  // (Princípios: IA como apoio, Decisão humana, Explicação)
  // ---------------------------------------------------------
  app.get('/api/v1/ai/evaluations', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, evaluations: db.aiEvaluations });
  });

  app.post('/api/v1/ai/evaluate-candidate', async (req: Request, res: Response) => {
    try {
      const { db, tenant } = req.tenantContext!;
      const { candidateId, jobOpeningId } = req.body;

      const candidate = db.candidates.find(c => c.id === candidateId);
      if (!candidate) return res.status(404).json({ success: false, error: 'Candidato não encontrado no banco deste tenant.' });

      const job = db.openings.find(j => j.id === jobOpeningId);
      if (!job) return res.status(404).json({ success: false, error: 'Vaga não encontrada no banco deste tenant.' });

      const position = db.positions.find(p => p.id === job.positionId);

      // Perform AI Assisted Evaluation server-side via Gemini API
      const aiResult = await evaluateCandidateWithAI({
        candidate,
        job,
        position,
        dna: db.dna
      });

      const evaluation = {
        id: `eval-${Date.now().toString().slice(-4)}`,
        evaluatedAt: new Date().toISOString(),
        ...aiResult
      };

      // Store in tenant isolated database
      db.aiEvaluations.unshift(evaluation);

      // Link to application if exists
      const appItem = db.applications.find(a => a.candidateId === candidateId && a.jobOpeningId === jobOpeningId);
      if (appItem) {
        appItem.aiEvaluationId = evaluation.id;
        appItem.notes.push(`[IA Apoio] Avaliação assistida concluída: Fit Geral ${evaluation.overallFitScore}%.`);
      }

      router.logMasterAudit(
        tenant.id,
        'usr-recruiter',
        'Recruiter/AI Engine',
        'AI_EVALUATION_COMPLETED',
        'AI_EXECUTION',
        `Avaliação de IA assistida concluída para candidato ${candidate.name} na vaga ${job.title}. Score: ${evaluation.overallFitScore}%`,
        req.ip || '127.0.0.1',
        tenant.dbConfig.dbName
      );

      res.status(201).json({ success: true, evaluation });
    } catch (err: any) {
      console.error('Error running AI evaluation:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Human Review & Override (Princípio: Decisão Humana)
  app.patch('/api/v1/ai/evaluations/:id/human-decision', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { decision, humanNotes, reviewerName } = req.body;
    const evalItem = db.aiEvaluations.find(e => e.id === req.params.id);
    if (!evalItem) return res.status(404).json({ success: false, error: 'Avaliação não encontrada' });

    evalItem.humanReviewerDecision = decision;
    evalItem.humanNotes = humanNotes;
    evalItem.reviewedBy = reviewerName || 'Recrutador Responsável';
    evalItem.reviewedAt = new Date().toISOString();

    res.json({ success: true, evaluation: evalItem });
  });

  // ---------------------------------------------------------
  // MÓDULO 10: Entrevistas
  // ---------------------------------------------------------
  app.get('/api/v1/interviews', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, interviews: db.interviews });
  });

  app.post('/api/v1/interviews', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { jobOpeningId, candidateId, stageName, scheduledFor, interviewerIds, durationMinutes, meetLink, structuredScript } = req.body;
    const newInterview = {
      id: `int-${Date.now().toString().slice(-4)}`,
      jobOpeningId,
      candidateId,
      stageName: stageName || 'Entrevista com RH',
      scheduledFor: scheduledFor || new Date(Date.now() + 86400000).toISOString(),
      interviewerIds: interviewerIds || [db.users[0]?.id || 'usr-1'],
      durationMinutes: Number(durationMinutes) || 45,
      meetLink: meetLink || 'https://meet.google.com/xyz-talent',
      status: 'scheduled' as const,
      structuredScript: structuredScript || [
        'Apresentação mútua e trajetória profissional',
        'Investigação das competências técnicas do cargo',
        'Validação dos pilares do DNA cultural da empresa'
      ],
      scorecard: [
        { competency: 'Aderência Cultural', score: 4, notes: '' },
        { competency: 'Competência Técnica', score: 4, notes: '' }
      ]
    };
    db.interviews.push(newInterview);
    res.status(201).json({ success: true, interview: newInterview });
  });

  app.patch('/api/v1/interviews/:id/scorecard', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { scorecard, recommendation, overallFeedback } = req.body;
    const interview = db.interviews.find(i => i.id === req.params.id);
    if (!interview) return res.status(404).json({ success: false, error: 'Entrevista não encontrada' });

    if (scorecard) interview.scorecard = scorecard;
    if (recommendation) interview.interviewerRecommendation = recommendation;
    if (overallFeedback) interview.overallFeedback = overallFeedback;
    interview.status = 'completed';

    res.json({ success: true, interview });
  });

  // ---------------------------------------------------------
  // MÓDULO 11: Proposta
  // ---------------------------------------------------------
  app.get('/api/v1/offers', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, offers: db.offers });
  });

  app.post('/api/v1/offers', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { jobOpeningId, candidateId, baseSalary, benefits, startDate, contractType } = req.body;
    const newOffer = {
      id: `off-${Date.now().toString().slice(-4)}`,
      jobOpeningId,
      candidateId,
      baseSalary: Number(baseSalary) || 15000,
      benefits: Array.isArray(benefits) ? benefits : ['Plano de Saúde', 'Vale Refeição', 'Seguro de Vida'],
      startDate: startDate || new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      contractType: contractType || 'CLT',
      status: 'pending_approval' as const,
      approverId: db.users.find(u => u.role === 'HIRING_MANAGER')?.id || db.users[0]?.id || 'usr-1'
    };
    db.offers.push(newOffer);
    res.status(201).json({ success: true, offer: newOffer });
  });

  app.patch('/api/v1/offers/:id/status', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { status, notes } = req.body;
    const offer = db.offers.find(o => o.id === req.params.id);
    if (!offer) return res.status(404).json({ success: false, error: 'Proposta não encontrada' });

    offer.status = status;
    if (notes) offer.notes = notes;
    if (status === 'sent') offer.sentAt = new Date().toISOString();
    if (status === 'accepted' || status === 'declined') offer.respondedAt = new Date().toISOString();

    res.json({ success: true, offer });
  });

  // ---------------------------------------------------------
  // MÓDULO 12: Onboarding
  // ---------------------------------------------------------
  app.get('/api/v1/onboardings', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, onboardings: db.onboardings });
  });

  app.patch('/api/v1/onboardings/:id/checklist/:itemId', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { status } = req.body;
    const journey = db.onboardings.find(o => o.id === req.params.id);
    if (!journey) return res.status(404).json({ success: false, error: 'Jornada de onboarding não encontrada' });

    const item = journey.checklists.find(c => c.id === req.params.itemId);
    if (!item) return res.status(404).json({ success: false, error: 'Item de checklist não encontrado' });

    item.status = status;
    res.json({ success: true, onboarding: journey });
  });

  // ---------------------------------------------------------
  // MÓDULO 13: Desenvolvimento (PDI e 1:1s)
  // ---------------------------------------------------------
  app.get('/api/v1/development', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, developmentRecords: db.developmentRecords });
  });

  app.post('/api/v1/development/:id/goals', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { title, competency, deadline } = req.body;
    const devRecord = db.developmentRecords.find(d => d.id === req.params.id);
    if (!devRecord) return res.status(404).json({ success: false, error: 'Registro de PDI não encontrado' });

    const newGoal = {
      id: `g-${Date.now().toString().slice(-4)}`,
      title,
      competency: competency || 'Geral',
      deadline: deadline || new Date(Date.now() + 90 * 86400000).toISOString().split('T')[0],
      status: 'in_progress' as const,
      progressPercentage: 10
    };
    devRecord.goals.push(newGoal);
    res.status(201).json({ success: true, goal: newGoal, developmentRecord: devRecord });
  });

  // ---------------------------------------------------------
  // MÓDULO 14: Retenção (eNPS, Clima & Termômetro de Turnover)
  // ---------------------------------------------------------
  app.get('/api/v1/retention', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({
      success: true,
      climateSurveys: db.climateSurveys,
      turnoverAlerts: db.turnoverAlerts
    });
  });

  app.post('/api/v1/retention/alert', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    const { collaboratorName, department, riskLevel, earlyWarningSignals, suggestedActions } = req.body;
    const newAlert = {
      id: `alt-${Date.now().toString().slice(-4)}`,
      collaboratorId: `colab-${Date.now().toString().slice(-4)}`,
      collaboratorName,
      department: department || 'Geral',
      riskLevel: riskLevel || 'Médio',
      earlyWarningSignals: Array.isArray(earlyWarningSignals) ? earlyWarningSignals : [earlyWarningSignals],
      suggestedActions: Array.isArray(suggestedActions) ? suggestedActions : [suggestedActions]
    };
    db.turnoverAlerts.push(newAlert);
    res.status(201).json({ success: true, alert: newAlert });
  });

  // ---------------------------------------------------------
  // MÓDULO 15: Indicadores (Tenant Analytics)
  // ---------------------------------------------------------
  app.get('/api/v1/indicators', (req: Request, res: Response) => {
    const { db } = req.tenantContext!;
    res.json({ success: true, indicators: db.indicators });
  });

  // ==========================================
  // VITE MIDDLEWARE (Development & Production)
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[TalentCloud Core] Server listening on http://0.0.0.0:${PORT}`);
    console.log(`[TalentCloud Core] Multi-tenancy Dynamic Routing Engine active`);
  });
}

startServer().catch(err => {
  console.error('Fatal: Failed to start TalentCloud Server:', err);
  process.exit(1);
});
