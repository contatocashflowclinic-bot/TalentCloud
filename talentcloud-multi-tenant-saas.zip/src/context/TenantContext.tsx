import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  Tenant,
  UserRole,
  TenantConnectionTelemetry,
  TenantRoutingResolution
} from '../types.js';
import {
  MasterApi,
  TenantApi,
  setActiveTenantSlug,
  getActiveTenantSlug,
  getLastRoutingResolution,
  getLastTelemetry
} from '../services/api.js';

interface TenantContextValue {
  activeTenant: Tenant | null;
  allTenants: Tenant[];
  isSuperAdminMode: boolean;
  currentRole: UserRole;
  telemetry: TenantConnectionTelemetry | null;
  routingResolution: TenantRoutingResolution | null;
  isLoading: boolean;
  error: string | null;
  switchTenant: (slug: string) => Promise<void>;
  setSuperAdminMode: (enabled: boolean) => void;
  setCurrentRole: (role: UserRole) => void;
  refreshTenants: () => Promise<Tenant[]>;
  refreshContext: () => Promise<void>;
}

const TenantContext = createContext<TenantContextValue | undefined>(undefined);

export const TenantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [allTenants, setAllTenants] = useState<Tenant[]>([]);
  const [activeTenant, setActiveTenant] = useState<Tenant | null>(null);
  const [isSuperAdminMode, setIsSuperAdminMode] = useState<boolean>(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('ORG_ADMIN');
  const [telemetry, setTelemetry] = useState<TenantConnectionTelemetry | null>(null);
  const [routingResolution, setRoutingResolution] = useState<TenantRoutingResolution | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const refreshTenants = useCallback(async () => {
    try {
      const tenants = await MasterApi.getTenants();
      setAllTenants(tenants);
      return tenants;
    } catch (err: any) {
      console.error('Failed to load tenants:', err);
      setError(err.message);
      return [];
    }
  }, []);

  const refreshContext = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await TenantApi.getContext();
      setActiveTenant(res.tenant);
      setTelemetry(res.telemetry);
      setRoutingResolution(res.routingResolution);
    } catch (err: any) {
      console.error('Failed to refresh tenant context:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const switchTenant = useCallback(async (slug: string) => {
    try {
      setIsLoading(true);
      setError(null);
      setActiveTenantSlug(slug);
      setIsSuperAdminMode(false);
      await refreshContext();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [refreshContext]);

  useEffect(() => {
    const init = async () => {
      setIsLoading(true);
      const tenants = await refreshTenants();
      if (tenants.length > 0) {
        // default to first active tenant (techcorp)
        const initialSlug = getActiveTenantSlug() || tenants[0].slug;
        setActiveTenantSlug(initialSlug);
        await refreshContext();
      }
      setIsLoading(false);
    };
    init();
  }, [refreshTenants, refreshContext]);

  return (
    <TenantContext.Provider
      value={{
        activeTenant,
        allTenants,
        isSuperAdminMode,
        currentRole,
        telemetry,
        routingResolution,
        isLoading,
        error,
        switchTenant,
        setSuperAdminMode: (enabled) => {
          setIsSuperAdminMode(enabled);
          if (enabled) {
            setCurrentRole('SUPER_ADMIN');
          } else {
            setCurrentRole('ORG_ADMIN');
          }
        },
        setCurrentRole,
        refreshTenants,
        refreshContext
      }}
    >
      {children}
    </TenantContext.Provider>
  );
};

export function useTenant() {
  const ctx = useContext(TenantContext);
  if (!ctx) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return ctx;
}
