import React, { useState } from 'react';
import { Building2, Database, Shield, Lock, Server, X, CheckCircle2, Sparkles } from 'lucide-react';
import { MasterApi } from '../services/api.js';
import { useTenant } from '../context/TenantContext.js';
import { DatabaseConfig } from '../types.js';

export const ProvisionOrganizationModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const { refreshTenants, switchTenant } = useTenant();

  const [name, setName] = useState('');
  const [tradingName, setTradingName] = useState('');
  const [slug, setSlug] = useState('');
  const [document, setDocument] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [plan, setPlan] = useState<'Starter' | 'Scale' | 'Enterprise'>('Scale');
  const [engineType, setEngineType] = useState<DatabaseConfig['engineType']>('PostgreSQL-Isolated');
  const [region, setRegion] = useState('southamerica-east1');
  const [adminUserName, setAdminUserName] = useState('');
  const [adminUserEmail, setAdminUserEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleNameChange = (val: string) => {
    setName(val);
    if (!slug || slug === name.toLowerCase().replace(/[^a-z0-9]/g, '-')) {
      const generatedSlug = val.toLowerCase().trim().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
      setSlug(generatedSlug);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !slug || !contactEmail) {
      setError('Por favor preencha os campos obrigatórios.');
      return;
    }

    try {
      setIsSubmitting(true);
      setError(null);
      const res = await MasterApi.provisionTenant({
        name,
        tradingName: tradingName || name,
        slug,
        document: document || '00.000.000/0001-00',
        contactEmail,
        plan,
        region,
        engineType,
        adminUserName: adminUserName || 'Administrador',
        adminUserEmail: adminUserEmail || contactEmail
      });

      await refreshTenants();
      await switchTenant(res.tenant.slug);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Falha ao provisionar organização.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const expectedDbName = `db_tenant_${slug || 'slug'}_prod`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-slate-200 p-6">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl border border-indigo-100">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Provisionar Nova Organização Tenant</h2>
              <p className="text-xs text-slate-500">
                Alocação dinâmica de banco de dados isolado e configuração de roteamento na Conta Mãe
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-5 space-y-4 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Razão Social *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="Ex: Nova Finanças S.A."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Nome Fantasia
              </label>
              <input
                type="text"
                value={tradingName}
                onChange={(e) => setTradingName(e.target.value)}
                placeholder="Ex: NovaBank"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Identificador Único (Slug de Roteamento) *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={slug}
                  onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                  placeholder="novabank"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Usado no roteamento HTTP (<code className="font-mono">X-Tenant-Slug: {slug || '...'}</code>)</p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                CNPJ / Documento Fiscal
              </label>
              <input
                type="text"
                value={document}
                onChange={(e) => setDocument(e.target.value)}
                placeholder="00.000.000/0001-00"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Email de Contato Institucional *
              </label>
              <input
                type="email"
                required
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                placeholder="rh@novabank.com.br"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Plano de Subscrição
              </label>
              <select
                value={plan}
                onChange={(e: any) => setPlan(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              >
                <option value="Starter">Starter (Pool 10 conn, 1GB)</option>
                <option value="Scale">Scale (Pool 15 conn, 2GB, IA ativa)</option>
                <option value="Enterprise">Enterprise (Pool 25 conn, 4GB, Vault dedicado)</option>
              </select>
            </div>
          </div>

          {/* Database Architecture Section */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-xs">
              <Database className="w-4 h-4 text-indigo-600" />
              Parâmetros da Conexão Isolada
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-600 mb-1">
                  Engine de Isolamento
                </label>
                <select
                  value={engineType}
                  onChange={(e: any) => setEngineType(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-xs bg-white"
                >
                  <option value="PostgreSQL-Isolated">PostgreSQL Isolated Schema Engine</option>
                  <option value="Encrypted-Tenant-Vault">Encrypted Tenant Vault (Saúde/Financeiro)</option>
                  <option value="Dedicated-Cluster">Cluster Físico Dedicado</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-600 mb-1">
                  Região de Hospedagem do Banco
                </label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-xs bg-white"
                >
                  <option value="southamerica-east1">southamerica-east1 (São Paulo, Brasil)</option>
                  <option value="us-east1">us-east1 (N. Virginia, EUA)</option>
                </select>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-slate-700 font-mono text-[11px] flex items-center justify-between">
              <div>
                <span className="text-slate-400">Banco Isolado a ser gerado:</span>{' '}
                <span className="text-indigo-600 font-semibold">{expectedDbName}</span>
              </div>
              <span className="text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Pool dedicado
              </span>
            </div>
          </div>

          {/* Initial Admin User */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Nome do Administrador Inicial
              </label>
              <input
                type="text"
                value={adminUserName}
                onChange={(e) => setAdminUserName(e.target.value)}
                placeholder="Ex: Mariana Santos"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Email do Administrador Inicial
              </label>
              <input
                type="email"
                value={adminUserEmail}
                onChange={(e) => setAdminUserEmail(e.target.value)}
                placeholder="mariana@novabank.com.br"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-medium text-xs transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              {isSubmitting ? 'Provisionando Banco...' : 'Confirmar e Provisionar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
