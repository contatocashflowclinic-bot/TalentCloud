import React, { useState, useEffect } from 'react';
import { FileCheck, Plus, CheckCircle2, XCircle, Send, DollarSign, Calendar, Clock } from 'lucide-react';
import { useTenant } from '../../context/TenantContext.js';
import { TenantApi } from '../../services/api.js';
import { JobOffer, Candidate, JobOpening } from '../../types.js';
import { formatDateSP } from '../../utils/dateUtils.js';

export const ModuleOffers: React.FC = () => {
  const { activeTenant } = useTenant();
  const [offers, setOffers] = useState<JobOffer[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [openings, setOpenings] = useState<JobOpening[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [candidateId, setCandidateId] = useState('');
  const [jobOpeningId, setJobOpeningId] = useState('');
  const [baseSalary, setBaseSalary] = useState(16000);
  const [benefitsInput, setBenefitsInput] = useState('Plano de Saúde Bradesco Top, VR R$ 1.200, Seguro de Vida');
  const [startDate, setStartDate] = useState(new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [offData, candData, opData] = await Promise.all([
        TenantApi.getOffers(),
        TenantApi.getCandidates(),
        TenantApi.getOpenings()
      ]);
      setOffers(offData);
      setCandidates(candData);
      setOpenings(opData);
      if (candData.length > 0) setCandidateId(candData[0].id);
      if (opData.length > 0) setJobOpeningId(opData[0].id);
    } catch (err) {
      console.error('Failed to load offers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [activeTenant?.id]);

  const handleCreateOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await TenantApi.createOffer({
        candidateId,
        jobOpeningId,
        baseSalary: Number(baseSalary),
        benefits: benefitsInput.split(',').map(s => s.trim()).filter(Boolean),
        startDate,
        contractType: 'CLT'
      });
      setIsModalOpen(false);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao criar proposta');
    }
  };

  const handleUpdateStatus = async (id: string, status: JobOffer['status']) => {
    try {
      await TenantApi.updateOfferStatus(id, status);
      await loadData();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Módulo 11</span>
            <span className="text-slate-300">•</span>
            <span className="text-xs font-mono text-slate-500">Banco: {activeTenant?.dbConfig?.dbName}</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Gestão de Propostas & Admissão</h1>
          <p className="text-xs text-slate-500">
            Formalização de ofertas salariais, controle de alçadas de aprovação e aceite do candidato.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Gerar Proposta
        </button>
      </div>

      {/* Offers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {offers.map((offer) => {
          const cand = candidates.find(c => c.id === offer.candidateId);
          const job = openings.find(j => j.id === offer.jobOpeningId);

          return (
            <div key={offer.id} className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    offer.status === 'accepted' ? 'bg-emerald-100 text-emerald-800' :
                    offer.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                    offer.status === 'approved' ? 'bg-purple-100 text-purple-800' :
                    offer.status === 'declined' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {offer.status === 'accepted' ? 'Aceita pelo Candidato' :
                     offer.status === 'sent' ? 'Enviada ao Candidato' :
                     offer.status === 'approved' ? 'Aprovada Internamente' :
                     offer.status === 'declined' ? 'Recusada' : 'Aprovação Pendente'}
                  </span>
                  <span className="font-mono text-xs font-bold text-slate-800">
                    R$ {offer.baseSalary.toLocaleString('pt-BR')}/mês
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base">{cand?.name || 'Candidato'}</h3>
                <div className="text-xs text-slate-500 font-medium">{job?.title}</div>

                <div className="pt-2 text-xs space-y-1 text-slate-600">
                  <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                    <Calendar className="w-3 h-3 text-indigo-600" /> Início: {formatDateSP(offer.startDate)} ({offer.contractType})
                  </div>
                  <div className="text-[11px] text-slate-500 line-clamp-2">
                    Benefícios: {offer.benefits.join(', ')}
                  </div>
                </div>
              </div>

              {/* Status Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
                {offer.status === 'pending_approval' && (
                  <button
                    onClick={() => handleUpdateStatus(offer.id, 'approved')}
                    className="w-full py-1.5 rounded-lg bg-indigo-50 text-indigo-700 font-semibold hover:bg-indigo-100 transition-colors"
                  >
                    Aprovar Alçada
                  </button>
                )}
                {offer.status === 'approved' && (
                  <button
                    onClick={() => handleUpdateStatus(offer.id, 'sent')}
                    className="w-full py-1.5 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" /> Enviar Formalmente
                  </button>
                )}
                {offer.status === 'sent' && (
                  <div className="w-full flex items-center gap-2">
                    <button
                      onClick={() => handleUpdateStatus(offer.id, 'accepted')}
                      className="flex-1 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold hover:bg-emerald-700 transition-colors"
                    >
                      Registrar Aceite
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(offer.id, 'declined')}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-rose-50 hover:text-rose-700 transition-colors"
                    >
                      Recusa
                    </button>
                  </div>
                )}
                {offer.status === 'accepted' && (
                  <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-1 mx-auto">
                    <CheckCircle2 className="w-4 h-4" /> Candidato contratado! Iniciar Onboarding
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md border border-slate-200 shadow-xl">
            <h3 className="text-base font-bold text-slate-900 mb-1">Gerar Nova Proposta Salarial</h3>
            <p className="text-xs text-slate-500 mb-4">A proposta será vinculada à base de dados do tenant.</p>

            <form onSubmit={handleCreateOffer} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Candidato</label>
                <select
                  value={candidateId}
                  onChange={(e) => setCandidateId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white"
                >
                  {candidates.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Vaga</label>
                <select
                  value={jobOpeningId}
                  onChange={(e) => setJobOpeningId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white"
                >
                  {openings.map(j => (
                    <option key={j.id} value={j.id}>{j.title}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Salário Base (R$)</label>
                  <input
                    type="number"
                    value={baseSalary}
                    onChange={(e) => setBaseSalary(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Data de Início</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pacote de Benefícios</label>
                <input
                  type="text"
                  value={benefitsInput}
                  onChange={(e) => setBenefitsInput(e.target.value)}
                  placeholder="Plano Médico, VR, Auxílio Creche, Seguro"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold"
                >
                  Submeter Proposta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
