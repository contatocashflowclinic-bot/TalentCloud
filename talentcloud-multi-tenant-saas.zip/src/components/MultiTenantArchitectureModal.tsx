import React from 'react';
import { Database, ShieldCheck, Cpu, ArrowRight, Server, CheckCircle2, Lock, Layers, Network, X } from 'lucide-react';
import { useTenant } from '../context/TenantContext.js';
import { formatDateTimeSP } from '../utils/dateUtils.js';

export const MultiTenantArchitectureModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { activeTenant, telemetry, routingResolution } = useTenant();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 md:p-8">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl border border-indigo-100">
              <Network className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Arquitetura Multi-Tenancy & Roteamento Dinâmico</h2>
              <p className="text-sm text-slate-500">
                Camada de abstração de conexão e isolamento estrito de dados por banco
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Active Route Box */}
        <div className="mt-6 p-4 rounded-xl bg-slate-900 text-white shadow-inner">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800">
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              ROTEAMENTO EM TEMPO REAL
            </span>
            <span className="font-mono text-[11px]" title="Fuso horário oficial: América/São Paulo">
              Horário SP: {formatDateTimeSP(new Date(), true)}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-3 pt-1 text-sm">
            <div>
              <span className="text-xs text-slate-400 block">Estratégia de Identificação</span>
              <span className="font-mono font-semibold text-amber-300">
                {routingResolution?.strategy || 'HEADER_INJECTION'}
              </span>
              <span className="text-xs text-slate-400 block mt-0.5 font-mono truncate">
                {routingResolution?.sourceValue || 'X-Tenant-Slug: ' + activeTenant?.slug}
              </span>
            </div>

            <div>
              <span className="text-xs text-slate-400 block">Organização Resolvida</span>
              <span className="font-semibold text-white truncate block">
                {activeTenant?.name || 'Carregando...'}
              </span>
              <span className="text-xs text-slate-400 block font-mono">ID: {activeTenant?.id}</span>
            </div>

            <div>
              <span className="text-xs text-slate-400 block">Banco Isolado Alvo</span>
              <span className="font-mono font-semibold text-cyan-300 truncate block">
                {activeTenant?.dbConfig?.dbName || 'db_tenant_default'}
              </span>
              <span className="text-xs text-slate-400 block font-mono">
                Porta: {activeTenant?.dbConfig?.port || 5432}
              </span>
            </div>

            <div>
              <span className="text-xs text-slate-400 block">Latência & Pool de Conexão</span>
              <span className="font-semibold text-emerald-300">
                {telemetry?.latencyMs || 6} ms • {telemetry?.activeConnections || 2}/{activeTenant?.dbConfig?.maxPoolSize || 20}
              </span>
              <span className="text-xs text-emerald-400 flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5" /> Isolamento verificado
              </span>
            </div>
          </div>
        </div>

        {/* Visual Pipeline Topology */}
        <div className="mt-8">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700 mb-4">
            Fluxo da Camada de Abstração
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
            {/* Step 1 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 relative">
              <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-sm mb-3">
                1
              </div>
              <h4 className="font-semibold text-slate-900 text-sm">Requisição do Cliente</h4>
              <p className="text-xs text-slate-600 mt-1">
                O navegador envia a requisição HTTP injetando o identificador dinâmico via <code className="bg-slate-200 px-1 py-0.5 rounded text-[11px]">X-Tenant-Slug</code> ou subdomínio.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/50 relative">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-sm mb-3">
                2
              </div>
              <h4 className="font-semibold text-indigo-950 text-sm">Dynamic Resolver</h4>
              <p className="text-xs text-slate-600 mt-1">
                O middleware do roteador intercepta o header, consulta o Catálogo Mestre da Conta Mãe e valida o status da organização.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/50 relative">
              <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-sm mb-3">
                3
              </div>
              <h4 className="font-semibold text-amber-950 text-sm">Connection Router</h4>
              <p className="text-xs text-slate-600 mt-1">
                A camada de abstração (<code className="bg-amber-100 px-1 py-0.5 rounded text-[11px]">TenantConnectionRouter</code>) obtém o pool de conexão do banco de dados isolado específico da empresa.
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 relative">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm mb-3">
                4
              </div>
              <h4 className="font-semibold text-emerald-950 text-sm">Banco Isolado Executado</h4>
              <p className="text-xs text-slate-600 mt-1">
                A consulta é executada exclusivamente na instância isolada do tenant. Zero risco de vazamento entre clientes corporativos.
              </p>
            </div>
          </div>
        </div>

        {/* Architectural Principles Grid */}
        <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <Lock className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <h5 className="font-semibold text-slate-900 text-sm">Isolamento Físico / Lógico</h5>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Cada organização possui sua própria base de dados dedicada (<code className="text-slate-800">db_tenant_[slug]_prod</code>), com credenciais de criptografia individuais (KMS).
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <Layers className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <h5 className="font-semibold text-slate-900 text-sm">Conta Mãe (SuperAdmin)</h5>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Gerencia configurações globais, provisionamento de novas instâncias, cotas de armazenamento e monitoramento de saúde de todos os nós.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <Cpu className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <h5 className="font-semibold text-slate-900 text-sm">IA Isolada por Tenant</h5>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                As avaliações assistidas por IA com Gemini 3.8 Flash utilizam estritamente o DNA cultural e os cargos do banco do tenant ativo, garantindo privacidade total.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium rounded-xl transition-colors"
          >
            Fechar Console
          </button>
        </div>
      </div>
    </div>
  );
};
