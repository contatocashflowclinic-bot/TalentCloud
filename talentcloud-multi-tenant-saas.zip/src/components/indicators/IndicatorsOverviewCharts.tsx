import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
  ReferenceLine
} from 'recharts';
import {
  Filter,
  TrendingDown,
  Clock,
  Users,
  Layers,
  Sparkles,
  Calendar,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { TenantIndicators, Department } from '../../types.js';

interface DepartmentMetricItem {
  id: string;
  name: string;
  code: string;
  turnoverRate: number;
  turnoverBenchmark: number;
  timeToFillDays: number;
  timeToFillSLA: number;
  openings: number;
  hires: number;
  headcount: number;
}

interface MonthlyTrendItem {
  month: string;
  timeToHireDays: number;
  hires: number;
  turnoverRate: number;
}

interface IndicatorsOverviewChartsProps {
  indicators: TenantIndicators | null;
  departments: Department[];
  tenantSlug?: string;
}

export const IndicatorsOverviewCharts: React.FC<IndicatorsOverviewChartsProps> = ({
  indicators,
  departments,
  tenantSlug = 'techcorp'
}) => {
  const [timeToFillView, setTimeToFillView] = useState<'byDept' | 'monthlyTrend'>('byDept');
  const [funnelMetricView, setFunnelMetricView] = useState<'volume' | 'conversion'>('volume');

  // Derive department metrics matching the active tenant
  const getDepartmentMetrics = (): DepartmentMetricItem[] => {
    if (tenantSlug === 'varejobr') {
      return [
        { id: '1', name: 'Operações & Lojas', code: 'LOJAS', turnoverRate: 8.4, turnoverBenchmark: 10.0, timeToFillDays: 14, timeToFillSLA: 20, openings: 8, hires: 24, headcount: 140 },
        { id: '2', name: 'Logística & Supply Chain', code: 'LOG', turnoverRate: 6.2, turnoverBenchmark: 8.5, timeToFillDays: 18, timeToFillSLA: 25, openings: 3, hires: 12, headcount: 65 },
        { id: '3', name: 'E-Commerce & Growth', code: 'ECOM', turnoverRate: 4.8, turnoverBenchmark: 7.0, timeToFillDays: 22, timeToFillSLA: 30, openings: 2, hires: 6, headcount: 28 },
        { id: '4', name: 'Atendimento / SAC', code: 'SAC', turnoverRate: 9.5, turnoverBenchmark: 11.0, timeToFillDays: 12, timeToFillSLA: 18, openings: 4, hires: 16, headcount: 52 },
        { id: '5', name: 'Gente & Gestão', code: 'RH', turnoverRate: 2.8, turnoverBenchmark: 5.0, timeToFillDays: 16, timeToFillSLA: 24, openings: 1, hires: 3, headcount: 14 }
      ];
    }

    if (tenantSlug === 'biosaude') {
      return [
        { id: '1', name: 'Análises Clínicas & Lab', code: 'LAB', turnoverRate: 1.4, turnoverBenchmark: 3.5, timeToFillDays: 34, timeToFillSLA: 40, openings: 2, hires: 4, headcount: 45 },
        { id: '2', name: 'Pesquisa & Biologia Molecular', code: 'BIO_MOL', turnoverRate: 0.9, turnoverBenchmark: 3.0, timeToFillDays: 38, timeToFillSLA: 45, openings: 1, hires: 2, headcount: 18 },
        { id: '3', name: 'Garantia Qualidade & Regulação', code: 'QUAL', turnoverRate: 1.1, turnoverBenchmark: 3.0, timeToFillDays: 29, timeToFillSLA: 35, openings: 1, hires: 1, headcount: 12 },
        { id: '4', name: 'Atendimento Médico', code: 'MED', turnoverRate: 1.6, turnoverBenchmark: 4.0, timeToFillDays: 26, timeToFillSLA: 30, openings: 1, hires: 3, headcount: 22 }
      ];
    }

    // Default TechCorp or customized department fallback
    if (departments.length > 0) {
      const baseDefaults = [
        { turnoverRate: 3.2, turnoverBenchmark: 6.0, timeToFillDays: 24, timeToFillSLA: 30, openings: 4, hires: 8 },
        { turnoverRate: 2.1, turnoverBenchmark: 5.0, timeToFillDays: 21, timeToFillSLA: 28, openings: 2, hires: 3 },
        { turnoverRate: 1.8, turnoverBenchmark: 5.5, timeToFillDays: 27, timeToFillSLA: 35, openings: 3, hires: 4 },
        { turnoverRate: 1.5, turnoverBenchmark: 4.0, timeToFillDays: 18, timeToFillSLA: 25, openings: 1, hires: 2 },
        { turnoverRate: 4.2, turnoverBenchmark: 7.0, timeToFillDays: 19, timeToFillSLA: 26, openings: 2, hires: 5 }
      ];

      return departments.map((d, index) => {
        const fallback = baseDefaults[index % baseDefaults.length];
        return {
          id: d.id,
          name: d.name,
          code: d.code || `D-${index + 1}`,
          turnoverRate: fallback.turnoverRate,
          turnoverBenchmark: fallback.turnoverBenchmark,
          timeToFillDays: fallback.timeToFillDays,
          timeToFillSLA: fallback.timeToFillSLA,
          openings: fallback.openings,
          hires: fallback.hires,
          headcount: d.currentHeadcount || 10
        };
      });
    }

    return [
      { id: '1', name: 'Engenharia de Software', code: 'ENG', turnoverRate: 3.2, turnoverBenchmark: 6.0, timeToFillDays: 24, timeToFillSLA: 30, openings: 4, hires: 8, headcount: 38 },
      { id: '2', name: 'Produto & Design', code: 'PRD', turnoverRate: 2.1, turnoverBenchmark: 5.0, timeToFillDays: 21, timeToFillSLA: 28, openings: 2, hires: 3, headcount: 15 },
      { id: '3', name: 'IA & Ciência de Dados', code: 'DATA_AI', turnoverRate: 1.8, turnoverBenchmark: 5.5, timeToFillDays: 27, timeToFillSLA: 35, openings: 3, hires: 4, headcount: 9 },
      { id: '4', name: 'People & Cultura (RH)', code: 'RH', turnoverRate: 1.5, turnoverBenchmark: 4.0, timeToFillDays: 18, timeToFillSLA: 25, openings: 1, hires: 2, headcount: 6 },
      { id: '5', name: 'Vendas & Customer Success', code: 'CS', turnoverRate: 4.2, turnoverBenchmark: 7.0, timeToFillDays: 19, timeToFillSLA: 26, openings: 2, hires: 5, headcount: 14 }
    ];
  };

  const departmentMetrics = getDepartmentMetrics();

  // Monthly trends (past 6 months)
  const monthlyTrends: MonthlyTrendItem[] = [
    { month: 'Out/25', timeToHireDays: 29, hires: 5, turnoverRate: 4.2 },
    { month: 'Nov/25', timeToHireDays: 27, hires: 7, turnoverRate: 3.8 },
    { month: 'Dez/25', timeToHireDays: 25, hires: 6, turnoverRate: 3.1 },
    { month: 'Jan/26', timeToHireDays: 24, hires: 8, turnoverRate: 2.8 },
    { month: 'Fev/26', timeToHireDays: 23, hires: 10, turnoverRate: 2.4 },
    { month: 'Mar/26', timeToHireDays: indicators?.timeToHireDays || 21, hires: indicators?.totalHiresThisQuarter || 12, turnoverRate: indicators?.earlyTurnover90DaysRate ? Number((indicators.earlyTurnover90DaysRate * 0.9).toFixed(1)) : 2.1 }
  ];

  // Funnel conversion stages derived from real indicators
  const funnel = indicators?.recruitmentFunnel || {
    applied: 184,
    screened: 82,
    interviewed: 34,
    offered: 11,
    hired: 9
  };

  const funnelData = [
    {
      stage: '1. Inscrições',
      label: 'Triagem Inicial',
      candidatos: funnel.applied,
      conversaoEtapa: 100,
      conversaoGlobal: 100,
      dropoff: 0,
      color: '#4f46e5' // indigo-600
    },
    {
      stage: '2. Fit Cultural IA',
      label: 'Calibração DNA',
      candidatos: funnel.screened,
      conversaoEtapa: Number(((funnel.screened / (funnel.applied || 1)) * 100).toFixed(1)),
      conversaoGlobal: Number(((funnel.screened / (funnel.applied || 1)) * 100).toFixed(1)),
      dropoff: funnel.applied - funnel.screened,
      color: '#2563eb' // blue-600
    },
    {
      stage: '3. Entrevista Técnica',
      label: 'Scorecard & Cases',
      candidatos: funnel.interviewed,
      conversaoEtapa: Number(((funnel.interviewed / (funnel.screened || 1)) * 100).toFixed(1)),
      conversaoGlobal: Number(((funnel.interviewed / (funnel.applied || 1)) * 100).toFixed(1)),
      dropoff: funnel.screened - funnel.interviewed,
      color: '#0891b2' // cyan-600
    },
    {
      stage: '4. Proposta Enviada',
      label: 'Oferta Salarial',
      candidatos: funnel.offered,
      conversaoEtapa: Number(((funnel.offered / (funnel.interviewed || 1)) * 100).toFixed(1)),
      conversaoGlobal: Number(((funnel.offered / (funnel.applied || 1)) * 100).toFixed(1)),
      dropoff: funnel.interviewed - funnel.offered,
      color: '#d97706' // amber-600
    },
    {
      stage: '5. Admissão',
      label: 'Contratação Aceita',
      candidatos: funnel.hired,
      conversaoEtapa: Number(((funnel.hired / (funnel.offered || 1)) * 100).toFixed(1)),
      conversaoGlobal: Number(((funnel.hired / (funnel.applied || 1)) * 100).toFixed(1)),
      dropoff: funnel.offered - funnel.hired,
      color: '#059669' // emerald-600
    }
  ];

  // Average turnover of the organization
  const avgTurnover = (
    departmentMetrics.reduce((acc, curr) => acc + curr.turnoverRate, 0) / departmentMetrics.length
  ).toFixed(1);

  // Average time to fill
  const avgTimeToFill = Math.round(
    departmentMetrics.reduce((acc, curr) => acc + curr.timeToFillDays, 0) / departmentMetrics.length
  );

  return (
    <div className="space-y-6">
      {/* Overview Analytics Bar Header */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Painel de Visão Geral Analítica & Gráficos
            </h2>
            <p className="text-xs text-slate-500">
              Visualização de pipelines seletivos, índice de turnover setorial e eficiência de tempo de preenchimento (SLA).
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700">
            <Calendar className="w-3.5 h-3.5 text-indigo-600" />
            <span className="font-semibold">Período:</span>
            <span className="font-mono text-indigo-700 font-bold">{indicators?.period || '2026-Q1'}</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-medium">Média Global:</span>
            <span className="font-mono font-bold">{avgTurnover}% turnover</span>
          </div>
        </div>
      </div>

      {/* Chart 1: Funil de Contratação (Recruitment Funnel) */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-indigo-50 text-indigo-700 border border-indigo-100">
                Pipeline Seletivo
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500 font-medium">Conversão E2E com IA Assistida</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 mt-1">
              Funil de Contratação & Taxas de Conversão
            </h3>
          </div>

          {/* Toggle View */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 self-start sm:self-auto">
            <button
              onClick={() => setFunnelMetricView('volume')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                funnelMetricView === 'volume'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Volume de Candidatos
            </button>
            <button
              onClick={() => setFunnelMetricView('conversion')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                funnelMetricView === 'conversion'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Taxas de Conversão (%)
            </button>
          </div>
        </div>

        {/* Funnel Visual KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {funnelData.map((item, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl border border-slate-100 bg-slate-50/60 flex flex-col justify-between"
            >
              <div>
                <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  {item.stage}
                </div>
                <div className="text-lg font-bold font-mono text-slate-900 mt-0.5">
                  {item.candidatos}{' '}
                  <span className="text-xs font-normal text-slate-500">cand.</span>
                </div>
              </div>
              <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Aderência:</span>
                <span className="font-mono font-bold text-indigo-600">
                  {item.conversaoGlobal}%
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Recharts Funnel Container */}
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={funnelData}
              layout="vertical"
              margin={{ top: 10, right: 30, left: 40, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
              <XAxis
                type="number"
                tick={{ fontSize: 11, fill: '#64748b' }}
                domain={funnelMetricView === 'volume' ? [0, 'dataMax + 20'] : [0, 100]}
                unit={funnelMetricView === 'volume' ? '' : '%'}
              />
              <YAxis
                type="category"
                dataKey="stage"
                tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                width={120}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1 border border-slate-800">
                        <div className="font-bold text-slate-100">{d.stage} ({d.label})</div>
                        <div className="text-indigo-300">
                          Volume: <span className="font-mono font-bold text-white">{d.candidatos}</span> candidatos
                        </div>
                        <div className="text-emerald-300">
                          Conversão da etapa: <span className="font-mono font-bold text-white">{d.conversaoEtapa}%</span>
                        </div>
                        <div className="text-slate-400">
                          Conversão fim-a-fim: <span className="font-mono font-bold text-white">{d.conversaoGlobal}%</span>
                        </div>
                        {d.dropoff > 0 && (
                          <div className="text-rose-300 text-[10px] pt-1 border-t border-slate-800">
                            Perda nesta transição: {d.dropoff} candidatos
                          </div>
                        )}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar
                dataKey={funnelMetricView === 'volume' ? 'candidatos' : 'conversaoEtapa'}
                name={funnelMetricView === 'volume' ? 'Candidatos' : 'Conversão (%)'}
                radius={[0, 8, 8, 0]}
              >
                {funnelData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600 flex-shrink-0" />
            <span>
              <strong>Eficiência de Triagem por IA:</strong> O filtro preditivo de Fit Cultural reduziu a carga de entrevistas técnicas em <strong>64.9%</strong>, encaminhando apenas perfis altamente compatíveis.
            </span>
          </div>
          <span className="hidden sm:inline font-mono text-[11px] text-slate-400">
            Taxa Final: {funnelData[4].conversaoGlobal}%
          </span>
        </div>
      </div>

      {/* Grid: Charts 2 & 3 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Chart 2: Turnover por Departamento */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-100">
                  Retenção & Clima
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 font-medium">90 Dias Pós-Admissão</span>
              </div>
              <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                Média: {avgTurnover}%
              </span>
            </div>

            <h3 className="text-base font-bold text-slate-900">
              Taxa de Turnover por Departamento
            </h3>
            <p className="text-xs text-slate-500">
              Comparativo entre a taxa de rotatividade apurada e o limite de tolerância (benchmark) do departamento.
            </p>
          </div>

          {/* Recharts BarChart Turnover */}
          <div className="h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={departmentMetrics}
                margin={{ top: 10, right: 10, left: -10, bottom: 25 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="code"
                  tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  unit="%"
                  domain={[0, 'dataMax + 2']}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload as DepartmentMetricItem;
                      const withinBenchmark = d.turnoverRate <= d.turnoverBenchmark;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1.5 border border-slate-800">
                          <div className="font-bold text-slate-100">{d.name}</div>
                          <div className="flex items-center justify-between gap-4 text-slate-300">
                            <span>Turnover Apurado:</span>
                            <span className="font-mono font-bold text-white">{d.turnoverRate}%</span>
                          </div>
                          <div className="flex items-center justify-between gap-4 text-slate-400">
                            <span>Benchmark Máximo:</span>
                            <span className="font-mono font-bold text-slate-200">{d.turnoverBenchmark}%</span>
                          </div>
                          <div className="flex items-center justify-between gap-4 text-slate-400">
                            <span>Quadro Atual:</span>
                            <span className="font-mono">{d.headcount} colaboradores</span>
                          </div>
                          <div className={`pt-1 border-t border-slate-800 font-semibold text-[10px] ${
                            withinBenchmark ? 'text-emerald-400' : 'text-rose-400'
                          }`}>
                            {withinBenchmark ? '✓ Em conformidade com a meta' : '⚠ Acima do limite tolerável'}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend
                  verticalAlign="top"
                  align="right"
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px', paddingBottom: '10px' }}
                />
                <ReferenceLine
                  y={Number(avgTurnover)}
                  stroke="#6366f1"
                  strokeDasharray="4 4"
                  label={{ value: `Média (${avgTurnover}%)`, fill: '#6366f1', fontSize: 10, position: 'top' }}
                />
                <Bar
                  dataKey="turnoverRate"
                  name="Turnover Apurado (%)"
                  fill="#ef4444"
                  radius={[6, 6, 0, 0]}
                >
                  {departmentMetrics.map((entry, index) => (
                    <Cell
                      key={`cell-to-${index}`}
                      fill={entry.turnoverRate <= entry.turnoverBenchmark ? '#10b981' : '#f43f5e'}
                    />
                  ))}
                </Bar>
                <Bar
                  dataKey="turnoverBenchmark"
                  name="Benchmark Máximo (%)"
                  fill="#cbd5e1"
                  radius={[6, 6, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Department Breakdown Mini-Cards */}
          <div className="pt-2 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-3 gap-2">
            {departmentMetrics.slice(0, 3).map((d) => {
              const isSafe = d.turnoverRate <= d.turnoverBenchmark;
              return (
                <div key={d.id} className="p-2 rounded-lg bg-slate-50 border border-slate-100 text-[11px]">
                  <div className="font-semibold text-slate-800 truncate" title={d.name}>
                    {d.name}
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="font-mono font-bold text-slate-900">{d.turnoverRate}%</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                      isSafe ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {isSafe ? 'Dentro' : 'Atenção'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 3: Tempo Médio de Preenchimento de Vagas (Time to Fill) */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-50 text-amber-700 border border-amber-100">
                  Eficiência Operacional
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 font-medium">Time to Fill / Hire</span>
              </div>

              {/* Toggle Dept vs Trend */}
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[11px]">
                <button
                  onClick={() => setTimeToFillView('byDept')}
                  className={`px-2.5 py-0.5 font-semibold rounded-md transition-all ${
                    timeToFillView === 'byDept'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Por Depto
                </button>
                <button
                  onClick={() => setTimeToFillView('monthlyTrend')}
                  className={`px-2.5 py-0.5 font-semibold rounded-md transition-all ${
                    timeToFillView === 'monthlyTrend'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Evolução Mensal
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900">
                {timeToFillView === 'byDept'
                  ? 'Tempo Médio de Preenchimento vs SLA'
                  : 'Evolução Histórica do Time to Hire (Últimos 6 Meses)'}
              </h3>
              <p className="text-xs text-slate-500">
                {timeToFillView === 'byDept'
                  ? 'Dias decorridos da abertura à aceitação da proposta comparados à meta SLA.'
                  : 'Demonstração do ganho de velocidade após implantação da triagem inteligente.'}
              </p>
            </div>
          </div>

          {/* Recharts Container */}
          <div className="h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              {timeToFillView === 'byDept' ? (
                <BarChart
                  data={departmentMetrics}
                  margin={{ top: 10, right: 10, left: -10, bottom: 25 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis
                    dataKey="code"
                    tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    unit="d"
                    domain={[0, 'dataMax + 5']}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload as DepartmentMetricItem;
                        const diff = d.timeToFillSLA - d.timeToFillDays;
                        return (
                          <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1.5 border border-slate-800">
                            <div className="font-bold text-slate-100">{d.name}</div>
                            <div className="flex items-center justify-between gap-4 text-indigo-300">
                              <span>Média Apurada:</span>
                              <span className="font-mono font-bold text-white">{d.timeToFillDays} dias</span>
                            </div>
                            <div className="flex items-center justify-between gap-4 text-slate-400">
                              <span>Meta SLA:</span>
                              <span className="font-mono font-bold text-slate-200">{d.timeToFillSLA} dias</span>
                            </div>
                            <div className="flex items-center justify-between gap-4 text-slate-400">
                              <span>Vagas Fechadas:</span>
                              <span className="font-mono">{d.hires} vagas</span>
                            </div>
                            <div className={`pt-1 border-t border-slate-800 font-semibold text-[10px] ${
                              diff >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }`}>
                              {diff >= 0 ? `✓ Fechamento ${diff} dias antes do prazo SLA` : `⚠ Ultrapassou SLA em ${Math.abs(diff)} dias`}
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    align="right"
                    iconType="circle"
                    wrapperStyle={{ fontSize: '11px', paddingBottom: '10px' }}
                  />
                  <ReferenceLine
                    y={30}
                    stroke="#94a3b8"
                    strokeDasharray="4 4"
                    label={{ value: 'SLA Padrão 30d', fill: '#94a3b8', fontSize: 10, position: 'top' }}
                  />
                  <Bar
                    dataKey="timeToFillDays"
                    name="Dias Médios para Fechamento"
                    fill="#6366f1"
                    radius={[6, 6, 0, 0]}
                  />
                  <Bar
                    dataKey="timeToFillSLA"
                    name="Meta SLA (dias)"
                    fill="#e2e8f0"
                    radius={[6, 6, 0, 0]}
                  />
                </BarChart>
              ) : (
                <LineChart
                  data={monthlyTrends}
                  margin={{ top: 10, right: 20, left: -10, bottom: 10 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    unit="d"
                    domain={['dataMin - 5', 'dataMax + 5']}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload as MonthlyTrendItem;
                        return (
                          <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1 border border-slate-800">
                            <div className="font-bold text-slate-100">{d.month}</div>
                            <div className="text-indigo-300">
                              Time to Hire: <span className="font-mono font-bold text-white">{d.timeToHireDays} dias</span>
                            </div>
                            <div className="text-emerald-300">
                              Contratações Realizadas: <span className="font-mono font-bold text-white">{d.hires}</span>
                            </div>
                            <div className="text-slate-400">
                              Taxa de Turnover: <span className="font-mono font-bold text-white">{d.turnoverRate}%</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    align="right"
                    iconType="circle"
                    wrapperStyle={{ fontSize: '11px', paddingBottom: '10px' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="timeToHireDays"
                    name="Time to Hire Médio (dias)"
                    stroke="#4f46e5"
                    strokeWidth={3}
                    dot={{ fill: '#4f46e5', r: 5, strokeWidth: 2, stroke: '#ffffff' }}
                    activeDot={{ r: 7 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="hires"
                    name="Contratações Realizadas"
                    stroke="#10b981"
                    strokeWidth={2}
                    strokeDasharray="3 3"
                    dot={{ fill: '#10b981', r: 4 }}
                  />
                </LineChart>
              )}
            </ResponsiveContainer>
          </div>

          {/* Insight footer */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-600" />
              <span>
                Tempo Médio Global: <strong className="text-slate-800 font-mono">{avgTimeToFill} dias</strong>
              </span>
            </div>
            <span className="text-emerald-600 font-semibold flex items-center gap-0.5">
              <TrendingDown className="w-3.5 h-3.5" />
              Redução de 27.5% no fechamento
            </span>
          </div>
        </div>

      </div>

      {/* Strategic People Analytics Summary Table */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider">
              Diagnóstico Consolidado por Departamento
            </h3>
            <p className="text-xs text-slate-500">
              Cruzamento de headcount, vagas abertas, rotatividade e conformidade de SLA de contratação.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {departmentMetrics.length} departamentos monitorados
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50/70">
                <th className="py-2.5 px-3">Departamento</th>
                <th className="py-2.5 px-3">Headcount</th>
                <th className="py-2.5 px-3">Vagas Abertas</th>
                <th className="py-2.5 px-3">Admissões (Trimestre)</th>
                <th className="py-2.5 px-3">Time to Fill Real</th>
                <th className="py-2.5 px-3">Meta SLA</th>
                <th className="py-2.5 px-3">Turnover Real</th>
                <th className="py-2.5 px-3">Benchmark</th>
                <th className="py-2.5 px-3 text-right">Status do Indicador</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {departmentMetrics.map((dept) => {
                const slaStatus = dept.timeToFillDays <= dept.timeToFillSLA;
                const turnoverStatus = dept.turnoverRate <= dept.turnoverBenchmark;

                return (
                  <tr key={dept.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 font-semibold text-slate-900">
                      {dept.name}
                      <span className="ml-1.5 px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-100 text-slate-500">
                        {dept.code}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-700">
                      {dept.headcount}
                    </td>
                    <td className="py-3 px-3 font-mono text-indigo-600 font-bold">
                      {dept.openings}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-700">
                      {dept.hires}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      {dept.timeToFillDays} dias
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-500">
                      {dept.timeToFillSLA} dias
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      {dept.turnoverRate}%
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-500">
                      {dept.turnoverBenchmark}%
                    </td>
                    <td className="py-3 px-3 text-right">
                      {slaStatus && turnoverStatus ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Excelente
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                          <AlertCircle className="w-3 h-3 text-amber-600" />
                          Acompanhar
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
