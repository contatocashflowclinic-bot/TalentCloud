import { Request } from 'express';
import {
  Tenant,
  SystemAuditLog,
  TenantConnectionTelemetry,
  TenantRoutingResolution,
  DatabaseConfig
} from '../../src/types.js';
import {
  TenantDatabaseEngine
} from './TenantDatabaseEngine.js';
import {
  INITIAL_TENANTS,
  INITIAL_MASTER_AUDIT_LOGS,
  getTechCorpSeedData,
  getVarejoBrSeedData,
  getBioSaudeSeedData
} from './masterSeed.js';

export interface TenantConnectionContext {
  tenant: Tenant;
  db: TenantDatabaseEngine;
  telemetry: TenantConnectionTelemetry;
  resolution: TenantRoutingResolution;
}

/**
 * TenantConnectionRouter
 * Abstraction layer responsible for:
 * 1. Dynamic Tenant Identification (Header, Subdomain, Query Parameter)
 * 2. Database Connection Routing with strict per-tenant data isolation
 * 3. SuperAdmin "Conta Mãe" management and dynamic tenant DB provisioning
 */
export class TenantConnectionRouter {
  private static instance: TenantConnectionRouter;

  // Master Catalog Data Store (Conta Mãe)
  private masterTenants: Map<string, Tenant> = new Map();
  private masterAuditLogs: SystemAuditLog[] = [];

  // Connection Pools for Isolated Tenant Databases
  private isolatedDatabasePools: Map<string, TenantDatabaseEngine> = new Map();

  private constructor() {
    this.initializeMasterCatalog();
  }

  public static getInstance(): TenantConnectionRouter {
    if (!TenantConnectionRouter.instance) {
      TenantConnectionRouter.instance = new TenantConnectionRouter();
    }
    return TenantConnectionRouter.instance;
  }

  private initializeMasterCatalog(): void {
    // Populate Master Tenants
    for (const tenant of INITIAL_TENANTS) {
      this.masterTenants.set(tenant.id, tenant);
    }
    this.masterAuditLogs = [...INITIAL_MASTER_AUDIT_LOGS];

    // Seed isolated databases for default tenants
    const tc = this.masterTenants.get('tenant-techcorp')!;
    this.isolatedDatabasePools.set(tc.id, new TenantDatabaseEngine(tc.id, tc.dbConfig, getTechCorpSeedData()));

    const vb = this.masterTenants.get('tenant-varejobr')!;
    this.isolatedDatabasePools.set(vb.id, new TenantDatabaseEngine(vb.id, vb.dbConfig, getVarejoBrSeedData()));

    const bio = this.masterTenants.get('tenant-biosaude')!;
    this.isolatedDatabasePools.set(bio.id, new TenantDatabaseEngine(bio.id, bio.dbConfig, getBioSaudeSeedData()));
  }

  /**
   * Dynamic Tenant Identification Strategy:
   * 1. Inspects HTTP Header 'x-tenant-id' or 'x-tenant-slug'
   * 2. Inspects Host Subdomain (e.g. techcorp.talentcloud.app)
   * 3. Inspects Query Parameter '?tenant=slug'
   * 4. Defaults to first active tenant if not specified
   */
  public resolveTenantFromRequest(req: Request): {
    strategy: TenantRoutingResolution['strategy'];
    sourceValue: string;
    tenant: Tenant | null;
  } {
    const startTime = Date.now();

    // 1. Explicit Header Identification (Preferred in SPA/API contexts)
    const headerTenantId = req.headers['x-tenant-id'] as string;
    const headerTenantSlug = req.headers['x-tenant-slug'] as string;

    if (headerTenantId) {
      const tenant = this.masterTenants.get(headerTenantId) || null;
      if (tenant) {
        return { strategy: 'HEADER_INJECTION', sourceValue: `x-tenant-id: ${headerTenantId}`, tenant };
      }
    }

    if (headerTenantSlug) {
      const tenant = Array.from(this.masterTenants.values()).find(t => t.slug.toLowerCase() === headerTenantSlug.toLowerCase()) || null;
      if (tenant) {
        return { strategy: 'HEADER_INJECTION', sourceValue: `x-tenant-slug: ${headerTenantSlug}`, tenant };
      }
    }

    // 2. Query parameter identification
    const queryTenant = (req.query.tenant as string) || (req.query.tenantId as string);
    if (queryTenant) {
      const tenant = this.masterTenants.get(queryTenant) || 
        Array.from(this.masterTenants.values()).find(t => t.slug.toLowerCase() === queryTenant.toLowerCase()) || null;
      if (tenant) {
        return { strategy: 'TOKEN_SESSION', sourceValue: `query: ${queryTenant}`, tenant };
      }
    }

    // 3. Subdomain identification
    const host = req.headers.host || '';
    const hostParts = host.split('.');
    if (hostParts.length > 2 && hostParts[0] !== 'www' && hostParts[0] !== 'localhost') {
      const subdomain = hostParts[0].toLowerCase();
      const tenant = Array.from(this.masterTenants.values()).find(t => t.slug.toLowerCase() === subdomain) || null;
      if (tenant) {
        return { strategy: 'SUBDOMAIN_DYNAMIC', sourceValue: `subdomain: ${subdomain}`, tenant };
      }
    }

    // Default fallback to first active tenant (TechCorp) for smooth preview
    const defaultTenant = this.masterTenants.get('tenant-techcorp') || Array.from(this.masterTenants.values())[0] || null;
    return {
      strategy: 'SUPERADMIN_IMPERSONATION',
      sourceValue: 'system_default_route',
      tenant: defaultTenant
    };
  }

  /**
   * Connection Routing Abstraction
   * Connects to the tenant's isolated database engine.
   * If not already cached in connection pool, provisions/attaches on the fly.
   */
  public routeConnection(req: Request): TenantConnectionContext {
    const startTime = Date.now();
    const resolutionInfo = this.resolveTenantFromRequest(req);

    if (!resolutionInfo.tenant) {
      throw new Error('Tenant identification failed: Organization does not exist or has been suspended.');
    }

    const tenant = resolutionInfo.tenant;

    if (tenant.status === 'suspended') {
      throw new Error(`Tenant '${tenant.name}' is currently suspended. Access denied.`);
    }

    // Retrieve or instantiate dedicated isolated database pool
    let dbEngine = this.isolatedDatabasePools.get(tenant.id);
    if (!dbEngine) {
      dbEngine = new TenantDatabaseEngine(tenant.id, tenant.dbConfig);
      this.isolatedDatabasePools.set(tenant.id, dbEngine);
      
      this.logMasterAudit(
        tenant.id,
        'SYSTEM',
        'System Router',
        'ISOLATED_DB_MOUNTED',
        'DB_PROVISIONING',
        `Dynamic connection pool mounted for isolated database: ${tenant.dbConfig.dbName}`,
        req.ip || '127.0.0.1',
        tenant.dbConfig.dbName
      );
    }

    // Record query on tenant engine
    dbEngine.recordQuery();

    const resolution: TenantRoutingResolution = {
      strategy: resolutionInfo.strategy,
      sourceValue: resolutionInfo.sourceValue,
      resolvedTenantId: tenant.id,
      targetDatabase: tenant.dbConfig.dbName,
      timestamp: new Date().toISOString(),
      latencyMs: Date.now() - startTime + Math.floor(Math.random() * 4) + 2
    };

    return {
      tenant,
      db: dbEngine,
      telemetry: dbEngine.getTelemetry(),
      resolution
    };
  }

  /**
   * SuperAdmin / Conta Mãe - Tenant Provisioning
   * Dynamically allocates an isolated database and sets up the routing catalog
   */
  public provisionNewOrganization(params: {
    name: string;
    tradingName: string;
    slug: string;
    document: string;
    contactEmail: string;
    plan: 'Starter' | 'Scale' | 'Enterprise';
    region?: string;
    engineType?: DatabaseConfig['engineType'];
    adminUserName: string;
    adminUserEmail: string;
  }): { tenant: Tenant; databaseConfig: DatabaseConfig } {
    const normalizedSlug = params.slug.toLowerCase().trim().replace(/[^a-z0-9-]/g, '-');

    // Check slug uniqueness
    const exists = Array.from(this.masterTenants.values()).some(t => t.slug === normalizedSlug);
    if (exists) {
      throw new Error(`O identificador (slug) '${normalizedSlug}' já está em uso por outra organização.`);
    }

    const tenantId = `tenant-${normalizedSlug}-${Date.now().toString().slice(-4)}`;
    const dbName = `db_tenant_${normalizedSlug}_prod`;
    const region = params.region || 'southamerica-east1';
    const engineType = params.engineType || 'PostgreSQL-Isolated';

    const dbConfig: DatabaseConfig = {
      dbId: `db-${normalizedSlug}-cluster`,
      dbName,
      host: `pg-cluster-${region}.talentcloud.internal`,
      port: 5432,
      engineType,
      maxPoolSize: params.plan === 'Enterprise' ? 25 : params.plan === 'Scale' ? 15 : 10,
      sslEnabled: true,
      region,
      schemaVersion: 'v2.4.0',
      encryptionKeyId: `kms-key-${normalizedSlug}-${Math.floor(Math.random() * 9000 + 1000)}`,
      storageUsedMb: 12.4,
      maxStorageMb: params.plan === 'Enterprise' ? 4096 : params.plan === 'Scale' ? 2048 : 1024
    };

    const newTenant: Tenant = {
      id: tenantId,
      name: params.name,
      tradingName: params.tradingName,
      slug: normalizedSlug,
      document: params.document,
      contactEmail: params.contactEmail,
      status: 'active',
      plan: params.plan,
      createdAt: new Date().toISOString(),
      dbConfig,
      features: {
        aiEvaluationEnabled: true,
        onboardingChecklistEnabled: true,
        retentionPredictorEnabled: params.plan !== 'Starter',
        advancedIndicatorsEnabled: true
      }
    };

    // Save in Master Catalog
    this.masterTenants.set(tenantId, newTenant);

    // Provision isolated database with initial admin and DNA
    const initialEngine = new TenantDatabaseEngine(tenantId, dbConfig, {
      dna: {
        tenantId,
        mission: `Promover o crescimento da ${params.tradingName} através de talentos de alto nível.`,
        vision: 'Construir uma equipe de alta performance e clima colaborativo.',
        archetype: 'Inovador & Ágil',
        cultureSummary: `Pilares culturais fundadores da ${params.tradingName}.`,
        coreValues: ['Integridade', 'Foco no Cliente', 'Inovação', 'Espírito de Equipe'],
        pillars: [
          {
            id: 'p1',
            name: 'Compromisso com o Resultado',
            description: 'Capacidade de cumprir acordos com excelência e qualidade.',
            weight: 5,
            expectedBehaviors: ['Entrega no prazo', 'Assume protagonismo'],
            undesiredBehaviors: ['Desculpa-se sem agir']
          },
          {
            id: 'p2',
            name: 'Trabalho em Equipe',
            description: 'Colaboração transparente e respeito às diferenças.',
            weight: 4,
            expectedBehaviors: ['Comunica-se com empatia', 'Ajuda os colegas'],
            undesiredBehaviors: ['Postura individualista']
          }
        ],
        culturalFitThreshold: 75,
        updatedAt: new Date().toISOString()
      },
      users: [
        {
          id: `usr-${tenantId}-admin`,
          tenantId,
          name: params.adminUserName,
          email: params.adminUserEmail,
          role: 'ORG_ADMIN',
          jobTitle: 'Administrador da Organização',
          active: true,
          lastLoginAt: new Date().toISOString(),
          permissions: ['ALL_ORG_PERMISSIONS']
        }
      ]
    });

    this.isolatedDatabasePools.set(tenantId, initialEngine);

    this.logMasterAudit(
      tenantId,
      'super-01',
      'SuperAdmin Root',
      'ORGANIZATION_CREATED',
      'DB_PROVISIONING',
      `Organização '${params.name}' criada com banco isolado '${dbName}' no cluster '${region}'`,
      '10.0.0.1',
      dbName
    );

    return { tenant: newTenant, databaseConfig: dbConfig };
  }

  public updateOrganizationStatus(tenantId: string, status: Tenant['status']): Tenant {
    const tenant = this.masterTenants.get(tenantId);
    if (!tenant) throw new Error('Organização não encontrada');
    tenant.status = status;
    this.masterTenants.set(tenantId, tenant);

    this.logMasterAudit(
      tenantId,
      'super-01',
      'SuperAdmin Root',
      'TENANT_STATUS_UPDATED',
      'ACCESS_CONTROL',
      `Status da organização '${tenant.name}' alterado para '${status}'`,
      '10.0.0.1',
      tenant.dbConfig.dbName
    );
    return tenant;
  }

  public getAllTenants(): Tenant[] {
    return Array.from(this.masterTenants.values());
  }

  public getTenantById(id: string): Tenant | undefined {
    return this.masterTenants.get(id);
  }

  public getTenantBySlug(slug: string): Tenant | undefined {
    return Array.from(this.masterTenants.values()).find(t => t.slug.toLowerCase() === slug.toLowerCase());
  }

  public getDatabaseEngine(tenantId: string): TenantDatabaseEngine | undefined {
    return this.isolatedDatabasePools.get(tenantId);
  }

  public getMasterAuditLogs(): SystemAuditLog[] {
    return [...this.masterAuditLogs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  public logMasterAudit(
    tenantId: string,
    userId: string,
    userName: string,
    action: string,
    category: SystemAuditLog['category'],
    details: string,
    ipAddress: string,
    databaseAffected: string
  ): void {
    const log: SystemAuditLog = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      tenantId,
      userId,
      userName,
      action,
      category,
      details,
      ipAddress,
      databaseAffected
    };
    this.masterAuditLogs.unshift(log);
    if (this.masterAuditLogs.length > 500) {
      this.masterAuditLogs.pop();
    }
  }

  public getGlobalTelemetry() {
    const tenants = Array.from(this.masterTenants.values());
    let totalStorageUsedMb = 0;
    let totalStorageMaxMb = 0;
    let totalActiveConnections = 0;
    let totalQueriesPerMinute = 0;

    const tenantBreakdowns = tenants.map(t => {
      const pool = this.isolatedDatabasePools.get(t.id);
      const telemetry = pool ? pool.getTelemetry() : {
        tenantId: t.id,
        dbName: t.dbConfig.dbName,
        activeConnections: 0,
        idleConnections: t.dbConfig.maxPoolSize,
        latencyMs: 0,
        queriesPerMinute: 0,
        lastConnectedAt: t.createdAt,
        status: 'healthy' as const,
        isolationVerified: true
      };

      totalStorageUsedMb += t.dbConfig.storageUsedMb;
      totalStorageMaxMb += t.dbConfig.maxStorageMb;
      totalActiveConnections += telemetry.activeConnections;
      totalQueriesPerMinute += telemetry.queriesPerMinute;

      return {
        tenantId: t.id,
        tenantName: t.name,
        slug: t.slug,
        status: t.status,
        dbName: t.dbConfig.dbName,
        engineType: t.dbConfig.engineType,
        region: t.dbConfig.region,
        telemetry
      };
    });

    return {
      totalTenants: tenants.length,
      activeTenants: tenants.filter(t => t.status === 'active').length,
      totalStorageUsedMb: Number(totalStorageUsedMb.toFixed(1)),
      totalStorageMaxMb,
      totalActiveConnections,
      totalQueriesPerMinute,
      activeIsolationEngines: this.isolatedDatabasePools.size,
      averageLatencyMs: 6.4,
      tenantBreakdowns
    };
  }
}
